package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.user;

/**
 * Servlet implementation class allpinfo
 */
@WebServlet("/allpinfo")
public class allpinfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public allpinfo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		Connection conn = Dbconn.getConnection();// ȡ������ 
try{
	 		
 			PreparedStatement st = conn.prepareStatement(
 					"select * from  pinfo ");

			ResultSet rs = st.executeQuery();// ִ�в�ѯ���
			response.setCharacterEncoding("GBK");
			response.setCharacterEncoding("GBK");
 			
 			while(rs.next()){
 				String user_id=rs.getString("user_id");
	      	      String name= rs.getString("name");
	      	      String sex = rs.getString("sex");
	      	      String birth=rs.getString("birth");
	      	      String edu=rs.getString("edu");
	      	      String location=rs.getString("location");
	      	      String hometown=rs.getString("hometown");
	      	      String phone=rs.getString("phone");
	      	      String seniority=rs.getInt("seniority")+"";
	      	      String wage=rs.getString("wage");
	      	    PrintWriter out=response.getWriter();
 				out.print("��ţ�"+user_id+"<br>");
 				out.print("������"+name+"<br>");
 				out.print("�Ա�"+sex+"<br>");
 				out.print("���᣺"+hometown+"<br>");
 				out.print("�������ڣ�"+birth+"<br>");
 				out.print("ѧ����"+edu+"<br>");
 				out.print("סַ��"+location+"<br>");
 				out.print("�绰��"+phone+"<br>");
 				out.print("���䣺"+seniority+"<br>");
 				out.print("�������ʣ�"+wage+"<br>");
 				out.print("**************************************************"+"<br>");
 				
 				

 		}
}
 		catch( SQLException e ){
 			System.out.printf( "���ݿ��ѯʧ��\n" + e.getMessage()  );
 			
 		}
 		finally{
 			if( conn != null ){
 				try{
 					conn.close();
 				}
 				catch( SQLException e ){
 					System.out.printf( "�ر�����ʧ��\n" + e.getMessage()+"\n"  );
 				}// try
 			// if
	}
 		}
 		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

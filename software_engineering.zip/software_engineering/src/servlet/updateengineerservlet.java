package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class updateengineerservlet
 */
@WebServlet("/updateengineerservlet")
public class updateengineerservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public updateengineerservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());

		Connection conn = Dbconn.getConnection();// ȡ������ 
		String category=request.getParameter("category");
		
		String information=new String(request.getParameter("information").getBytes("ISO8859-1"),"UTF-8");
		 try{
		 		
	 			PreparedStatement st = conn.prepareStatement(
	 					"select * from  pinfo where "+category+ " = '" + information +"'");
	 			ResultSet rs = st.executeQuery();// ִ�в�ѯ���
	 			int number=0;
	 			//rs.last();
	 			int irow=rs.getRow();
	 			System.out.print("select * from  pinfo where "+category+ " = '" + information +"'");
	 			response.setCharacterEncoding("gbk");
	 		/*	if(irow==0)
	 			{
	 				response.setCharacterEncoding("gbk");
					PrintWriter out = response.getWriter();
					out.print("<script>alert('��Ϣ�����ڻ���Ϣ�������'); \r\n" + "window.history.go(-1) </script>");
					out.flush();
					out.close();
	 			}*/
	 			//rs.first();
	 			System.out.print(information);
	 			while(rs.next())
	 			{
	 				String user_id=rs.getString("user_id");

		      	      String name= rs.getString("name");
		      	      String sex = rs.getString("sex");
		      	      String birth=rs.getString("birth");
		      	      String edu=rs.getInt("edu")+"";
		      	      String location=rs.getString("location");
		      	      String hometown=rs.getString("hometown");
		      	      String phone=rs.getString("phone");
		      	      String seniority=rs.getInt("seniority")+"";
		      	      String wage=rs.getString("wage");
		      	      
		      	  
		      	      String[] s=birth.split("-");
		      	      String year=s[0];
		      	      String month=s[1];
		      	      String day=s[2];
		      	      number++;
		      	      request.setAttribute("user_id", user_id);
			      	  request.setAttribute("name", name);
			      	  request.setAttribute("sex", sex);
			      	  request.setAttribute("edu", edu);
			      	  request.setAttribute("location", location);
			      	  request.setAttribute("hometown", hometown);
			      	  request.setAttribute("phone", phone);
			      	  request.setAttribute("seniority", seniority);
			      	  request.setAttribute("wage", wage);
			      	  request.setAttribute("year", year);
			      	  request.setAttribute("month", month);
			      	  request.setAttribute("day", day);
		      	    System.out.printf("aaa"+ year+month+day+number );
		      	    
					PrintWriter out = response.getWriter();
;
	 				out.print("��ţ�"+user_id+"<br>");
	 				out.print("������"+name+"<br>");
	 				out.print("�Ա�"+sex+"<br>");
	 				out.print("���᣺"+hometown+"<br>");
	 				out.print("�������ڣ�"+birth+"<br>");
	 				out.print("ѧ����"+edu+"<br>");
	 				out.print("סַ��"+location+"<br>");
	 				out.print("�绰��"+phone+"<br>");
	 				out.print("���䣺"+seniority+"<br>");
	 				out.print("�������ʣ�"+wage+"<br>");
	 				out.print("**************************************************"+"<br>");
	 			}
	 			
	 			if(number==0) {
	 				response.setCharacterEncoding("gbk");
					PrintWriter out = response.getWriter();
					out.print("<script>alert('��Ϣ�����ڻ���Ϣ�������');window.close(); </script>");
					out.flush();
					out.close();
	 			}
	 			
	      	    if(number>1)
	      	    {
	      	    	response.setCharacterEncoding("utf-8");
					PrintWriter out = response.getWriter();
					out.print("<script>alert('�ж��������ͬ�Ĺ���ʦ�����������idʹ��id��ѯ�޸ģ�'); </script>");
					out.flush();
					out.close();
					
	      	    }else {
	      	    	RequestDispatcher dispatcher=request.getRequestDispatcher("update.jsp");
		            dispatcher.forward(request,response);  //ת��
	      	    }
	      	    
	      	     
	      	    
	 			System.out.printf( "��ѯ�ɹ�\n" );
	 		//	System.out.print(rs.getRow());
	 			//System.out.print(rs.getString(1));
	 			
	 			
	 		}
	 		catch( SQLException e ){
	 			System.out.printf( "��ѯʧ��\n" + e.getMessage()  );
	 			response.setCharacterEncoding("gbk");
				PrintWriter out = response.getWriter();
				out.print("<script>alert('��Ϣ�����ڻ���Ϣ�������'); \r\n" + "window.history.go(-1) </script>");
				out.flush();
				out.close();
	 		}
	 		finally{
	 			if( conn != null ){
	 				try{
	 					conn.close();
	 				}
	 				catch( SQLException e ){
	 					System.out.printf( "�ر�����ʧ��\n" + e.getMessage()+"\n"  );
	 				}// try
	 			}// if
	 			
	 		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package servlet;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

/**
 * Servlet implementation class downtxtservlet
 */
@WebServlet("/downtxtservlet")
public class downtxtservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public downtxtservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String path="D://my";
		File folder=new File(path);
		if(!folder.exists() && !folder.isDirectory()){
		    //文件夾不存在時创建文件夾
		    folder.mkdirs();
		}
		String fileName="D://my//my.txt";
		File file=new File(fileName);
		if(file.exists())
		{
			file.delete();
		}
		if(!file.exists()){
		    //文件不存在時创建文件
		    file.createNewFile();
		}
		Connection conn = Dbconn.getConnection();// 取得连接 
		BufferedWriter out = null;
		try{
			 		
		 			PreparedStatement st = conn.prepareStatement(
		 					"select * from  pinfo ");

					ResultSet rs = st.executeQuery();// 执行查询语句
					
		 			while(rs.next()){
		 				
		 				out = new BufferedWriter(new OutputStreamWriter(
		 						new FileOutputStream(file, true)));
		 				String data="";
		 				for(int i=1;i<=10;i++)
		 				{
		 					data+=rs.getString(i)+"    ";
		 				}

		 				

		 				out.write(data+"\n");
		 				out.close();
		 				

		 		}
		 			response.setCharacterEncoding("gbk");
		 			PrintWriter out1 = response.getWriter();
	 				out1.print("<script>alert('文件已保存，D://my//my.txt目录下！'); \r\n" + "window.history.go(-1); </script>");
	 				out1.flush();
	 				out1.close();
		}
		 		catch( SQLException e ){
		 			System.out.printf( "数据库查询失败\n" + e.getMessage()  );
		 			response.setCharacterEncoding("gbk");
		 			PrintWriter out1 = response.getWriter();
	 				out1.print("<script>alert('文件保存失败！'); \r\n" + "window.close(); </script>");
	 				out1.flush();
	 				out1.close();
		 		}
		 		finally{
		 			if( conn != null ){
		 				try{
		 					conn.close();
		 					
		 				}
		 				catch( SQLException e ){
		 					System.out.printf( "关闭连接失败\n" + e.getMessage()+"\n"  );
		 				}// try
		 			// if
			}
		
		 		}

	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

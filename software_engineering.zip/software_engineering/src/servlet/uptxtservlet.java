package servlet;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



/**
 * Servlet implementation class uptxtservlet
 */
@WebServlet("/uptxtservlet")
public class uptxtservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public uptxtservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String filepath=request.getParameter("file");
		response.setCharacterEncoding("GBK");
		PrintWriter out=response.getWriter();
		List<String> content = new ArrayList<String>();
    	String lineTxt = "";
    	Connection conn = Dbconn.getConnection();// ȡ������ 
        try {
            BufferedReader buffReader = new BufferedReader(new InputStreamReader(new FileInputStream(new File(filepath)), "gbk"));
            while ((lineTxt = buffReader.readLine()) != null) {
                content.add(lineTxt);
                String [] arr = lineTxt.split("\\s+");
                String user_id=arr[0];
      	      String name= arr[1];
      	      String sex = arr[2];
      	      String birth=arr[3];
      	     
      	      String edu=arr[4];
      	      String hometown=arr[5];
      	      String location=arr[6];
      	      String phone=arr[7];
      	      String seniority=arr[8];
      	      String wage=arr[9];
      	    
      	  PreparedStatement st = conn.prepareStatement(
					"insert into pinfo values('"+user_id+"','"+name+"','"+sex+"','"+birth+"','"+edu+"','"+hometown+"','"+location+"','"+phone+"','"+seniority+"','"+wage+"')");
			st.executeUpdate();
			
			 
			
                out.print(lineTxt);
                out.print("<br>");
               
            }
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
 			String time=df.format(new Date());
 			HttpSession session=request.getSession();
 			Object username = session.getAttribute("username");
 			String info="�û�"+username+"�����˹���ʦ��Ϣ";
 			PreparedStatement st1 = conn.prepareStatement(
 					"insert into OperationRecord values('"+username+"','"+time+"','"+info+"')");
 			st1.executeUpdate();
            buffReader.close();
            
            
            
            PrintWriter out1 = response.getWriter();
			out1.print("<script>alert('�ļ��ϴ��ɹ���'); \r\n" + "window.close(); </script>");
			out1.flush();
			out1.close();
        } catch (Exception e) {
            System.err.println("read errors :" + e);
            response.setCharacterEncoding("gbk");
			PrintWriter out1 = response.getWriter();
			out1.print("<script>alert('�ļ���ʽ�����ݴ���'); \r\n" + "window.history.go(-1) </script>");
			out1.flush();
			out1.close();
        }

		
			out.print("��ţ�"+filepath+"<br>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

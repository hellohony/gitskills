package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class calsalaryservlet
 */
@WebServlet("/calsalaryservlet")
public class calsalaryservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public calsalaryservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String user_id=new String(request.getParameter("user_id").getBytes("ISO8859-1"),"UTF-8");
	    String daynumber= new String(request.getParameter("daynumber").getBytes("ISO8859-1"),"UTF-8");
	    String income = new String(request.getParameter("income").getBytes("ISO8859-1"),"UTF-8");
	    String insurance=new String(request.getParameter("insurance").getBytes("ISO8859-1"),"UTF-8");
	   
	    Connection conn = Dbconn.getConnection();// ȡ������ 
	    try{
	    	PreparedStatement st1 = conn.prepareStatement(
 					"select * from  pinfo where user_id = '" + user_id +"'");

			ResultSet rs = st1.executeQuery();// ִ�в�ѯ���
			
			if(rs.next())
			{
				PreparedStatement st2 = conn.prepareStatement(
	 					"select * from  pwage where user_id = '" + user_id +"'");

				ResultSet rs2 = st2.executeQuery();// ִ�в�ѯ���
				if(rs2.next()) 
				{
					PreparedStatement st3=conn.prepareStatement("DELETE FROM pwage WHERE user_id='" +user_id+"'");
					st3.executeUpdate();
				}
				String name=rs.getString("name");
				int seniority=Integer.parseInt(rs.getString("seniority"));
				int wage=Integer.parseInt(rs.getString("wage"));
				double result=(Integer.parseInt(daynumber)*10+wage+Integer.parseInt(income)*seniority/100)*0.9-Integer.parseInt(insurance);
				String s=result+"";
		    	PreparedStatement st = conn.prepareStatement(
	 					"insert into pwage values('"+user_id+"','"+name+"','"+daynumber+"','"+income+"','"+insurance+"','"+s+"')");
	 			st.executeUpdate();
	 			
	 			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
	 			String time=df.format(new Date());
	 			HttpSession session=request.getSession();
	 			Object username = session.getAttribute("username");
	 			String info="�û�"+username+"�����˹���ʦ"+user_id+"��нˮ";
	 			PreparedStatement st5 = conn.prepareStatement(
	 					"insert into OperationRecord values('"+username+"','"+time+"','"+info+"')");
	 			st5.executeUpdate();
	 			
	 			
	 			response.setCharacterEncoding("gbk");
	 			 PrintWriter out=response.getWriter();
					out.print("��ţ�"+user_id+"<br>");
					out.print("нˮ��"+s+"<br>");
			}
			else
 			{
 				response.setCharacterEncoding("gbk");
				PrintWriter out = response.getWriter();
				out.print("<script>alert('��Ϣ�����ڻ���Ϣ�������'); \r\n" + "window.history.go(-1) </script>");
				out.flush();
				out.close();
 			}
 			
 			
 		}
 		catch( SQLException e ){
 			System.out.printf( "��ѯʧ��\n" + e.getMessage()  );
 			response.setCharacterEncoding("gbk");
			PrintWriter out = response.getWriter();
			out.print("<script>alert('��Ϣ�����ڻ���Ϣ�������'); \r\n" + "window.history.go(-1) </script>");
			out.flush();
			out.close();
 		}
 		finally{
 			if( conn != null ){
 				try{
 					conn.close();
 				}
 				catch( SQLException e ){
 					System.out.printf( "�ر�����ʧ��\n" + e.getMessage()+"\n"  );
 				}// try
 			}// if
 			
 		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

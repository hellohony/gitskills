package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class updateuserservlet
 */
@WebServlet("/updateuserservlet")
public class updateuserservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public updateuserservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		Connection conn = Dbconn.getConnection();// ȡ������ 
		String zh=new String(request.getParameter("zh").getBytes("ISO8859-1"),"UTF-8");
	      String mm= new String(request.getParameter("mm").getBytes("ISO8859-1"),"UTF-8");
	      
		
		 try{
		 		
	 			PreparedStatement st = conn.prepareStatement(
	 					"UPDATE login SET password='"+mm+"'"+" WHERE user_id = '"+zh+"'");
	 			st.executeUpdate();
	 			
	 			System.out.printf( "�޸ĳɹ�\n" );
	 			response.setCharacterEncoding("gbk");
				PrintWriter out = response.getWriter();
				out.print("<script>alert('�޸ĳɹ���'); \r\n" + "window.history.go(-1) </script>");
				out.flush();
				out.close();	
	 			
	 			
	 		}
	 		catch( SQLException e ){
	 			System.out.printf( "�޸�ʧ��\n" + e.getMessage()  );

	 				response.setCharacterEncoding("gbk");
					PrintWriter out = response.getWriter();
					out.print("<script>alert('�û������ڻ���Ϣ�������'); \r\n" + "window.history.go(-1) </script>");
					out.flush();
					out.close();
	 			
	 		}
	 		finally{
	 			if( conn != null ){
	 				try{
	 					conn.close();
	 				}
	 				catch( SQLException e ){
	 					System.out.printf( "�ر�����ʧ��\n" + e.getMessage()+"\n"  );
	 				}// try
	 			}
	 		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

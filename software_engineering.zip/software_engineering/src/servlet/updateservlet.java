package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class updateservlet
 */
@WebServlet("/updateservlet")
public class updateservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public updateservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());


		Connection conn = Dbconn.getConnection();// ȡ������ 
		  //String user_id=new String(request.getParameter("user_id").getBytes("ISO8859-1"));
		//String user_id=new String(request.getParameter("user_id").getBytes("ISO8859-1"),"UTF-8");

		String user_id=request.getParameter("user_id");
	      String name= new String(request.getParameter("name").getBytes("ISO8859-1"),"gbk");
	      String sex = new String(request.getParameter("sexname").getBytes("ISO8859-1"),"gbk");
	      String year=new String(request.getParameter("year").getBytes("ISO8859-1"),"gbk");
	      String month=new String(request.getParameter("month").getBytes("ISO8859-1"),"gbk");
	      String day=new String(request.getParameter("day").getBytes("ISO8859-1"),"gbk");
	      String edu=new String(request.getParameter("eduname").getBytes("ISO8859-1"),"gbk");
	      String location=new String(request.getParameter("location").getBytes("ISO8859-1"),"gbk");
	      String hometown=new String(request.getParameter("hometown").getBytes("ISO8859-1"),"gbk");
	      String phone=new String(request.getParameter("phone").getBytes("ISO8859-1"),"gbk");
	      String seniority=new String(request.getParameter("seniority").getBytes("ISO8859-1"),"gbk");
	      String wage=new String(request.getParameter("wage").getBytes("ISO8859-1"),"gbk");
	      String birth=year+"-"+month+"-"+day;
	      
	      try{
		 		
	 			PreparedStatement st = conn.prepareStatement(
	 					"UPDATE pinfo SET  name = '"+name+"', sex='"+sex +"', birth='"+birth +"', edu='"+edu +"', location='"+location +"', hometown='"+hometown
	 					+"',phone='"+phone+"', seniority='"+seniority+"', wage='"+wage+
	 					"' WHERE user_id = '"+user_id+"'");
	 			
	 			st.executeUpdate();
	 			
	 			PreparedStatement st5 = conn.prepareStatement(
	 					"UPDATE pwage SET  name = '"+name+
	 					"' WHERE user_id = '"+user_id+"'");
	 			
	 			st5.executeUpdate();
	 			
	 		    System.out.print("UPDATE pinfo SET  name = '"+name+"', sex='"+sex +"', birth='"+birth +"', edu='"+edu +"', location='"+location +"', hometown='"+hometown
	 					+"',phone='"+phone+"', seniority='"+seniority+"', wage='"+wage+
	 					"' WHERE user_id = '"+user_id+"'");
	 			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
	 			String time=df.format(new Date());
	 			HttpSession session=request.getSession();
	 			Object username = session.getAttribute("username");
	 			String info="�û�"+username+"�޸��˹���ʦ"+user_id+"����Ϣ";
	 			PreparedStatement st1 = conn.prepareStatement(
	 					"insert into OperationRecord values('"+username+"','"+time+"','"+info+"')");
	 			st1.executeUpdate();
	 			
	 			System.out.printf( "���³ɹ�\n" );
	 			
	 			response.setCharacterEncoding("gbk");
				PrintWriter out = response.getWriter();
				out.print("<script>alert('�޸ĳɹ���'); \r\n" + "window.close(); </script>");
				out.flush();
				out.close();
	 			
	 			
	 		}
	 		catch( SQLException e ){
	 			System.out.printf( "����ʧ��\n" + e.getMessage()  );
	 			System.out.printf( "UPDATE pinfo SET  name = '"+name+"',set sex='"+sex +"', birth='"+birth +"', edu='"+edu +"', location='"+location +"', hometown='"+hometown
	 					+"',phone='"+phone+"', seniority='"+seniority+"', wage='"+wage+
	 					" WHERE user_id = '"+user_id+"'" );
	 			response.setCharacterEncoding("gbk");
				PrintWriter out = response.getWriter();
				out.print("<script>alert('��Ϣ�����ڻ���Ϣ�������'); \r\n" + "window.history.go(-1) </script>");
				out.flush();
				out.close();
	 		}
	 		finally{
	 			if( conn != null ){
	 				try{
	 					conn.close();
	 				}
	 				catch( SQLException e ){
	 					System.out.printf( "�ر�����ʧ��\n" + e.getMessage()+"\n"  );
	 				}// try
	 			}// if
	 			
	 		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

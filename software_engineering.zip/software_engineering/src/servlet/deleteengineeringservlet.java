package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class deleteengineeringservlet
 */
@WebServlet("/deleteengineeringservlet")
public class deleteengineeringservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public deleteengineeringservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		Connection conn = Dbconn.getConnection();// ȡ������ 
		String category=request.getParameter("category");
		
		String information=new String(request.getParameter("information").getBytes("ISO8859-1"),"UTF-8");
		 try{
		 		
	 			PreparedStatement st = conn.prepareStatement(
	 					"DELETE FROM pinfo WHERE " + category + "='"+information+"'");
	 			st.executeUpdate();
	 			
	 			if(category.equals("user_id"))
	 			{
	 				PreparedStatement st2 = conn.prepareStatement(
		 					"DELETE FROM pwage WHERE user_id='"+information+"'");
		 			st2.executeUpdate();
	 			}
	 			else if(category.equals("name"))
	 			{
	 				PreparedStatement st2 = conn.prepareStatement(
		 					"DELETE FROM pwage WHERE name='"+information+"'");
		 			st2.executeUpdate();
	 			}
	 			
	 			
	 			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
	 			String time=df.format(new Date());
	 			HttpSession session=request.getSession();
	 			Object username = session.getAttribute("username");
	 			String info="�û�"+username+"ɾ���˹���ʦ"+information;
	 			PreparedStatement st1 = conn.prepareStatement(
	 					"insert into OperationRecord values('"+username+"','"+time+"','"+info+"')");
	 			st1.executeUpdate();
	 			
	 			
	 			
	 			System.out.printf( "DELETE FROM pinfo WHERE " + category + "='"+information+"'" );
	 			System.out.printf( "ɾ���ɹ�\n" );
	 			response.setCharacterEncoding("gbk");
				PrintWriter out = response.getWriter();
				out.print("<script>alert('ɾ���ɹ���'); \r\n" + "window.history.go(-1) </script>");
				out.flush();
				out.close();	
	 			
	 			
	 		}
	 		catch( SQLException e ){
	 			System.out.printf( "ɾ��ʧ��\n" + e.getMessage()  );

	 				response.setCharacterEncoding("gbk");
					PrintWriter out = response.getWriter();
					out.print("<script>alert('��Ϣ�����ڻ���Ϣ�������'); \r\n" + "window.history.go(-1) </script>");
					out.flush();
					out.close();
	 			
	 		}
	 		finally{
	 			if( conn != null ){
	 				try{
	 					conn.close();
	 				}
	 				catch( SQLException e ){
	 					System.out.printf( "�ر�����ʧ��\n" + e.getMessage()+"\n"  );
	 				}// try
	 			}// if
	 			
	 		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

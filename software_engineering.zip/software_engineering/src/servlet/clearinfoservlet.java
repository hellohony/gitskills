package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.user;

/**
 * Servlet implementation class clearinfoservlet
 */
@WebServlet("/clearinfoservlet")
public class clearinfoservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public clearinfoservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		Connection conn = Dbconn.getConnection();// ȡ������ 


	
			
		try{
	 		
 			PreparedStatement st = conn.prepareStatement(
 					"truncate pinfo");

			st.execute();// ִ�в�ѯ���
			
			PreparedStatement st2 = conn.prepareStatement(
 					"truncate pwage");

			st2.execute();// ִ�в�ѯ���
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
 			String time=df.format(new Date());
 			HttpSession session=request.getSession();
 			Object username = session.getAttribute("username");
 			String info="�û�"+username+"���������";
 			PreparedStatement st1 = conn.prepareStatement(
 					"insert into OperationRecord values('"+username+"','"+time+"','"+info+"')");
 			st1.executeUpdate();
			
			response.setCharacterEncoding("gb2312");
			PrintWriter out = response.getWriter();
			out.print("<script>alert('��ճɹ�'); window.close() </script>");
			out.flush();
			out.close();
 		}
 		catch( SQLException e ){
 			System.out.printf( "���ݿ��ѯʧ��\n" + e.getMessage()  );
 			response.setCharacterEncoding("gb2312");
 			PrintWriter out = response.getWriter();
			out.print("<script>alert('���ʧ��'); window.location='index.jsp' </script>");
			out.flush();
			out.close();
 		}
 		finally{
 			if( conn != null ){
 				try{
 					conn.close();
 				}
 				catch( SQLException e ){
 					System.out.printf( "�ر�����ʧ��\n" + e.getMessage()+"\n"  );
 				}// try
 			}// if
 			
 		}// finally
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

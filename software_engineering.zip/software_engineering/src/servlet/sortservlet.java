package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class sortservlet
 */
@WebServlet("/sortservlet")
public class sortservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public sortservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		Connection conn = Dbconn.getConnection();// ȡ������ 
		String sortinfo=request.getParameter("sort");
		String sql="";
		if(sortinfo.equals("1"))
		{
			sql="select * from pinfo  order by user_id asc";
		}else if(sortinfo.equals("2"))
		{
			sql="select * from pinfo  order by user_id desc";
		}else if(sortinfo.equals("3"))
		{
			sql="select * from pinfo  order by name asc";
		}else if(sortinfo.equals("4"))
		{
			sql="select * from pinfo  order by name desc";
		}else if(sortinfo.equals("5")) 
		{
			sql="select * from pinfo  order by seniority asc";
		}else if(sortinfo.equals("6"))
		{
			sql="select * from pinfo  order by seniority desc";
		}
		try{
	 		
 			PreparedStatement st = conn.prepareStatement(sql);
 			ResultSet rs = st.executeQuery();// ִ�в�ѯ���
 			response.setCharacterEncoding("GBK");

 			response.getWriter().write("<br><br>");
 			while(rs.next()){
 				String user_id=rs.getString("user_id");
	      	      String name= rs.getString("name");
	      	      String sex = rs.getString("sex");
	      	      String birth=rs.getString("birth");
	      	      String edu=rs.getString("edu");
	      	      String location=rs.getString("location");
	      	      String hometown=rs.getString("hometown");
	      	      String phone=rs.getString("phone");
	      	      String seniority=rs.getInt("seniority")+"";
	      	      String wage=rs.getString("wage");
	      	    PrintWriter out=response.getWriter();
 				out.print("��ţ�"+user_id+"<br>");
 				out.print("������"+name+"<br>");
 				out.print("�Ա�"+sex+"<br>");
 				out.print("���᣺"+hometown+"<br>");
 				out.print("�������ڣ�"+birth+"<br>");
 				out.print("ѧ����"+edu+"<br>");
 				out.print("סַ��"+location+"<br>");
 				out.print("�绰��"+phone+"<br>");
 				out.print("���䣺"+seniority+"<br>");
 				out.print("�������ʣ�"+wage+"<br>");
 				out.print("**************************************************"+"<br>");
 			}
 			
 		}
 		catch( SQLException e ){
 			System.out.printf( "��ѯʧ��\n" + e.getMessage()  );
 			
 		}
 		finally{
 			if( conn != null ){
 				try{
 					conn.close();
 				}
 				catch( SQLException e ){
 					System.out.printf( "�ر�����ʧ��\n" + e.getMessage()+"\n"  );
 				}// try
 			}// if
 			
 		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

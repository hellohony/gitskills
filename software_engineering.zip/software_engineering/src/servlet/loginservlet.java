package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.user;

import java.sql.Connection;

@WebServlet("/login")
public class loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginservlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = (String)request.getParameter("username");
		String password = (String)request.getParameter("password");
		Connection conn = Dbconn.getConnection();// ȡ������ 
		request.setAttribute("username", username);
		

			

			
		try{
	 		
 			PreparedStatement st = conn.prepareStatement(
 					"select * from  login where user_id = '" + username +"'");

			ResultSet rs = st.executeQuery();// ִ�в�ѯ���
 			
			HttpSession session=request.getSession();
 			
 			if (rs.next()){
 				
 				user from_db = new user();
 				from_db.setUser(rs.getString("user_id"));
 				from_db.setPassword(rs.getString("password"));
 				if (from_db.getPassword().equals(password)){
 					System.out.println( "�˺�������ȷ��" );
 				System.out.println(from_db.toString());
 				session.setAttribute("username", username);
 				
 				if(from_db.getUser().equals("adm"))
 					request.getRequestDispatcher( "glindex.jsp").forward(request,response); 
 				else
 					
 					request.getRequestDispatcher( "index.jsp").forward(request,response); 
 					
 					
 				}
 				else{
 					System.out.println("�������");
 					response.setCharacterEncoding("gbk");
 					PrintWriter out = response.getWriter();
 					out.print("<script>alert('�������'); window.location='login.jsp' </script>");
 					out.flush();
 					out.close();
 					//response.sendRedirect("login.jsp");
 				}
 			}
 			else{
 				System.out.println("�˺Ų�����");
 				response.setCharacterEncoding("gbk");
					PrintWriter out = response.getWriter();
					out.print("<script>alert('�˺Ų�����'); window.location='login.jsp' </script>");
					out.flush();
					out.close();
 				//response.sendRedirect("login.jsp");
 			}
 			
 		}
 		catch( SQLException e ){
 			System.out.printf( "���ݿ��ѯʧ��\n" + e.getMessage()  );
 			
 		}
 		finally{
 			if( conn != null ){
 				try{
 					conn.close();
 				}
 				catch( SQLException e ){
 					System.out.printf( "�ر�����ʧ��\n" + e.getMessage()+"\n"  );
 				}// try
 			}// if
 			
 		}// finally
 		
 		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		/*RequestDispatcher dispatcher=request.getRequestDispatcher("index.jsp");
		dispatcher.forward(request,response);  //ת��   
		request.setAttribute("message",password);   */
		
		

		//response.sendRedirect("index.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
